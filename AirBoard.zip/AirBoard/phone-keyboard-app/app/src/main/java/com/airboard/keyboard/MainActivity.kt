package com.airboard.keyboard

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothProfile
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var hidManager: HidKeyboardManager
    private lateinit var statusText: TextView
    private lateinit var liveInput: EditText

    private var lastLength = 0

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            hidManager.start()
        } else {
            statusText.text = "Bluetooth permissions are required to pair as a keyboard."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        liveInput = findViewById(R.id.liveInput)
        val sendEnterButton = findViewById<Button>(R.id.sendEnterButton)
        val clearButton = findViewById<Button>(R.id.clearButton)

        hidManager = HidKeyboardManager(this)
        hidManager.listener = object : HidKeyboardManager.ConnectionListener {
            override fun onHidDeviceRegistered() {
                runOnUiThread { statusText.text = "Ready. Pair this phone from your TV's Bluetooth settings." }
            }

            override fun onHidDeviceUnregistered() {
                runOnUiThread { statusText.text = "HID service stopped." }
            }

            override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
                runOnUiThread {
                    statusText.text = when (state) {
                        BluetoothProfile.STATE_CONNECTED -> "Connected to ${device?.name ?: "TV"}. Type below to send keystrokes."
                        BluetoothProfile.STATE_CONNECTING -> "Connecting..."
                        BluetoothProfile.STATE_DISCONNECTED -> "Not connected. Pair from your TV's Bluetooth settings."
                        else -> statusText.text
                    }
                }
            }

            override fun onAppUnavailable(reason: String) {
                runOnUiThread {
                    statusText.text = "Unavailable: $reason"
                    Toast.makeText(this@MainActivity, reason, Toast.LENGTH_LONG).show()
                }
            }
        }

        // Every keystroke typed here is streamed live to the paired TV as HID reports.
        liveInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                val text = s?.toString() ?: ""
                if (text.length > lastLength) {
                    // Characters were appended/inserted -- send just the new tail.
                    val added = text.substring(lastLength)
                    hidManager.sendText(added)
                } else if (text.length < lastLength) {
                    // Characters were deleted -- send backspace(s) for the delta.
                    repeat(lastLength - text.length) { hidManager.sendBackspace() }
                }
                lastLength = text.length
            }
        })

        sendEnterButton.setOnClickListener { hidManager.sendEnter() }
        clearButton.setOnClickListener {
            liveInput.setText("")
            lastLength = 0
        }

        requestBtPermissionsAndStart()
    }

    private fun requestBtPermissionsAndStart() {
        if (!hidManager.isProfileSupported()) {
            statusText.text = "This device does not support Bluetooth."
            return
        }
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            needed += Manifest.permission.BLUETOOTH_CONNECT
            needed += Manifest.permission.BLUETOOTH_ADVERTISE
        }
        if (needed.isEmpty()) {
            hidManager.start()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        hidManager.stop()
    }
}
