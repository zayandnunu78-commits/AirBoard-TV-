package com.airboard.keyboard

/**
 * Standard USB HID "boot protocol" keyboard report descriptor.
 * This is the same descriptor used by virtually every basic BT/USB keyboard,
 * which is important for maximum compatibility with Google TV / Android TV hosts.
 *
 * Report layout (8 bytes total, Report ID 1):
 *   byte 0: modifier keys bitmask (ctrl/shift/alt/meta, left+right)
 *   byte 1: reserved (always 0)
 *   bytes 2-7: up to 6 simultaneously pressed key usage codes
 */
object HidKeyboardConstants {

    val KEYBOARD_REPORT_DESCRIPTOR: ByteArray = byteArrayOf(
        0x05, 0x01,             // Usage Page (Generic Desktop)
        0x09, 0x06,             // Usage (Keyboard)
        0xA1.toByte(), 0x01,    // Collection (Application)
        0x85.toByte(), 0x01,    //   Report ID (1)
        0x05, 0x07,             //   Usage Page (Key Codes)
        0x19, 0xE0.toByte(),    //   Usage Minimum (224)
        0x29, 0xE7.toByte(),    //   Usage Maximum (231)
        0x15, 0x00,             //   Logical Minimum (0)
        0x25, 0x01,             //   Logical Maximum (1)
        0x75, 0x01,             //   Report Size (1)
        0x95.toByte(), 0x08,    //   Report Count (8)
        0x81.toByte(), 0x02,    //   Input (Data, Variable, Absolute) - modifier byte
        0x95.toByte(), 0x01,    //   Report Count (1)
        0x75, 0x08,             //   Report Size (8)
        0x81.toByte(), 0x01,    //   Input (Constant) - reserved byte
        0x95.toByte(), 0x05,    //   Report Count (5)
        0x75, 0x01,             //   Report Size (1)
        0x05, 0x08,             //   Usage Page (LEDs)
        0x19, 0x01,             //   Usage Minimum (1)
        0x29, 0x05,             //   Usage Maximum (5)
        0x91.toByte(), 0x02,    //   Output (Data, Variable, Absolute) - LED report
        0x95.toByte(), 0x01,    //   Report Count (1)
        0x75, 0x03,             //   Report Size (3)
        0x91.toByte(), 0x01,    //   Output (Constant) - LED padding
        0x95.toByte(), 0x06,    //   Report Count (6)
        0x75, 0x08,             //   Report Size (8)
        0x15, 0x00,             //   Logical Minimum (0)
        0x25, 0x65,             //   Logical Maximum (101)
        0x05, 0x07,             //   Usage Page (Key Codes)
        0x19, 0x00,             //   Usage Minimum (0)
        0x29, 0x65,             //   Usage Maximum (101)
        0x81.toByte(), 0x00,    //   Input (Data, Array) - up to 6 keys
        0xC0.toByte()           // End Collection
    )

    const val REPORT_ID: Byte = 1
    const val REPORT_SIZE = 8

    // Modifier bitmask values
    const val MOD_NONE: Int = 0x00
    const val MOD_LEFT_SHIFT: Int = 0x02
    const val MOD_LEFT_CTRL: Int = 0x01
    const val MOD_LEFT_ALT: Int = 0x04

    // A subset of USB HID keyboard usage IDs, sufficient for typed text + editing.
    val CHAR_TO_USAGE: Map<Char, Int> = buildMap {
        // a-z -> 0x04-0x1D
        for (i in 0..25) put(('a' + i), 0x04 + i)
        // 1-9 -> 0x1E-0x26, 0 -> 0x27
        for (i in 1..9) put(('0' + i), 0x1E + (i - 1))
        put('0', 0x27)
        put('\n', 0x28) // Enter
        put(' ', 0x2C)  // Space
        put('-', 0x2D)
        put('=', 0x2E)
        put('[', 0x2F)
        put(']', 0x30)
        put('\\', 0x31)
        put(';', 0x33)
        put('\'', 0x34)
        put('`', 0x35)
        put(',', 0x36)
        put('.', 0x37)
        put('/', 0x38)
    }

    // Characters that require the Shift modifier on a standard US layout,
    // mapped to the base (unshifted) usage code that produces them with shift held.
    val SHIFTED_CHAR_TO_USAGE: Map<Char, Int> = buildMap {
        val upperBase = 0x04
        for (i in 0..25) put(('A' + i), upperBase + i)
        val shiftedSymbols = mapOf(
            '!' to 0x1E, '@' to 0x1F, '#' to 0x20, '$' to 0x21, '%' to 0x22,
            '^' to 0x23, '&' to 0x24, '*' to 0x25, '(' to 0x26, ')' to 0x27,
            '_' to 0x2D, '+' to 0x2E, '{' to 0x2F, '}' to 0x30, '|' to 0x31,
            ':' to 0x33, '"' to 0x34, '~' to 0x35, '<' to 0x36, '>' to 0x37, '?' to 0x38
        )
        putAll(shiftedSymbols)
    }

    // Non-printable / control key usage codes
    const val USAGE_BACKSPACE = 0x2A
    const val USAGE_TAB = 0x2B
    const val USAGE_ESC = 0x29
    const val USAGE_ARROW_RIGHT = 0x4F
    const val USAGE_ARROW_LEFT = 0x50
    const val USAGE_ARROW_DOWN = 0x51
    const val USAGE_ARROW_UP = 0x52
    const val USAGE_DELETE = 0x4C
}
