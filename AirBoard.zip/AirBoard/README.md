# AirBoard

Two Android Studio projects:

- **phone-keyboard-app/** — runs on the phone. Registers as a Bluetooth HID
  keyboard peripheral (`BluetoothHidDevice`) and streams every keystroke you
  type into its text box to whatever host it's paired to, live.
- **tv-receiver-app/** — runs on the Google TV / Android TV device (e.g. onn.
  box). An `AccessibilityService` intercepts D-pad key events from the
  physical remote and drives a system-wide on-screen cursor overlay, with
  ramp acceleration on sustained holds and click-via-gesture-dispatch.

## Setup

1. Open each folder as a separate project in Android Studio (Giraffe+ /
   AGP 8.5, Kotlin 1.9.24).
2. Install `tv-receiver-app` on the Google TV device (`adb install`, or
   sideload via a file manager / Downloader app since it won't be on Play
   Store during development).
3. Launch it, tap **Open Accessibility Settings**, find **AirBoard Cursor**,
   turn it on.
4. On the TV: **Settings → Remote & Accessories → Add accessory** (or
   equivalent) and put it in pairing mode.
5. Install `phone-keyboard-app` on the phone, open it, grant Bluetooth
   permissions, and pair the phone from the TV's Bluetooth settings — the
   TV will see it as a normal keyboard named "AirBoard Keyboard".
6. Type in the phone app's text box; keystrokes appear wherever the TV's
   text cursor/focus currently is.
7. On the physical TV remote: **long-press BACK (~1s)** to toggle mouse
   mode on/off. While on, D-pad moves the on-screen pointer (accelerating
   the longer you hold a direction) and the center/select button clicks.
   A short BACK press while mouse mode is on turns it back off; while off,
   BACK behaves completely normally.

## Important technical notes / limitations

- **HID peripheral hardware support varies by phone.** `BluetoothHidDevice`
  requires API 28+, but whether the Bluetooth chipset/stack actually
  supports the peripheral ("device") role — as opposed to only the
  central/host role — depends on the specific phone. Test early on your
  actual hardware; there's no universal compatibility list.
- **The TV remote's motion isn't real gyro/motion data.** Google TV/onn.
  remotes expose standard D-pad `KeyEvent`s to third-party apps, not raw
  Bluetooth motion packets (only Google's own launcher gets that, from
  Google's own remote). The "mouse pointer" here is built by translating
  held D-pad direction into accelerating cursor movement — this is the same
  approach real remote-to-pointer accessibility tools use, and it does work
  system-wide across launcher and apps, but it's a translation layer, not
  raw motion sensing.
- **Character coverage in the phone app is a starting set**
  (letters, digits, common punctuation, space/enter/backspace) via
  `HidKeyboardConstants` — extend `CHAR_TO_USAGE` / `SHIFTED_CHAR_TO_USAGE`
  for more symbols, arrow-key shortcuts, etc.
- **Placeholder icons/banner**: both apps ship with simple vector-drawable
  placeholders (`ic_launcher.xml`, `app_banner.xml`) so the projects build
  out of the box — swap in real art before distributing.
- Neither app has been compiled in this environment (no Android SDK/build
  tools available here) — review/build in Android Studio and fix any
  version-drift issues (AGP/Kotlin/SDK releases move fast).
