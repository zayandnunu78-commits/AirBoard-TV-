package com.airboard.tvreceiver

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/**
 * Lightweight custom view drawn inside a TYPE_ACCESSIBILITY_OVERLAY window.
 * Renders a simple arrow-like pointer plus a subtle drop shadow for visibility
 * against any background (video, launcher, streaming app UI, etc).
 */
class CursorOverlayView(context: Context) : View(context) {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val activeRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4FC3F7")
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    var isActive: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    companion object {
        const val CURSOR_RADIUS_PX = 16f
        const val VIEW_SIZE_PX = (CURSOR_RADIUS_PX * 4).toInt() // padding for ring + shadow
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f

        if (isActive) {
            canvas.drawCircle(cx, cy, CURSOR_RADIUS_PX + 6f, activeRingPaint)
        }
        canvas.drawCircle(cx, cy, CURSOR_RADIUS_PX, fillPaint)
        canvas.drawCircle(cx, cy, CURSOR_RADIUS_PX, strokePaint)
    }
}
