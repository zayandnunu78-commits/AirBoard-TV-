package com.airboard.tvreceiver

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Captures D-pad key events from the physical TV remote (delivered as standard
 * Android KeyEvents once this service requests key event filtering) and turns
 * sustained directional holds into a smooth, system-wide mouse-style pointer,
 * rendered via a TYPE_ACCESSIBILITY_OVERLAY window so it draws above every
 * launcher screen and streaming app.
 *
 * Pointer mode is OFF by default so normal remote navigation (D-pad focus
 * movement, back, etc.) is untouched. Long-press BACK (~700ms) toggles
 * pointer mode on/off; while it's on, D-pad presses move the cursor instead
 * of moving focus, and DPAD_CENTER/ENTER performs a tap at the cursor
 * location.
 */
class CursorAccessibilityService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: CursorOverlayView
    private lateinit var overlayParams: WindowManager.LayoutParams
    private lateinit var pointerController: PointerController

    private val mainHandler = Handler(Looper.getMainLooper())
    private var frameLoopRunning = false
    private var pointerModeActive = false

    private var backDownTimeMs: Long = 0L
    private val longPressThresholdMs = 700L
    private var longPressToggleRunnable: Runnable? = null

    companion object {
        private const val FRAME_INTERVAL_MS = 16L // ~60fps
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        pointerController = PointerController(metrics.widthPixels, metrics.heightPixels)

        setupOverlay()
        Toast.makeText(this, "AirBoard cursor ready. Long-press BACK to toggle.", Toast.LENGTH_LONG).show()
    }

    private fun setupOverlay() {
        overlayView = CursorOverlayView(this).apply { isActive = pointerModeActive }

        val overlayType = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY

        overlayParams = WindowManager.LayoutParams(
            CursorOverlayView.VIEW_SIZE_PX,
            CursorOverlayView.VIEW_SIZE_PX,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            x = pointerController.x.toInt()
            y = pointerController.y.toInt()
        }

        windowManager.addView(overlayView, overlayParams)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        when (event.keyCode) {
            KeyEvent.KEYCODE_BACK -> return handleBackKey(event)

            KeyEvent.KEYCODE_DPAD_UP,
            KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (!pointerModeActive) return false // let normal focus navigation happen
                handleDirectionalKey(event)
                return true // consume: we're driving the cursor instead of focus
            }

            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER -> {
                if (!pointerModeActive) return false
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    performTapAtCursor()
                }
                return true
            }
        }
        return false
    }

    private fun handleBackKey(event: KeyEvent): Boolean {
        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0) {
                    val runnable = Runnable { togglePointerMode() }
                    longPressToggleRunnable = runnable
                    mainHandler.postDelayed(runnable, longPressThresholdMs)
                }
                // Don't consume yet -- we don't know if this will be a long press.
                return false
            }
            KeyEvent.ACTION_UP -> {
                longPressToggleRunnable?.let { mainHandler.removeCallbacks(it) }
                longPressToggleRunnable = null
                // If pointer mode is active, BACK also exits pointer mode on short press
                // so the user always has a fast way out.
                if (pointerModeActive) {
                    togglePointerMode()
                    return true
                }
                return false
            }
        }
        return false
    }

    private fun togglePointerMode() {
        pointerModeActive = !pointerModeActive
        overlayView.isActive = pointerModeActive
        if (!pointerModeActive) {
            stopFrameLoop()
        }
        Toast.makeText(
            this,
            if (pointerModeActive) "AirBoard cursor ON" else "AirBoard cursor OFF",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun handleDirectionalKey(event: KeyEvent) {
        val direction = when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> PointerController.Direction.UP
            KeyEvent.KEYCODE_DPAD_DOWN -> PointerController.Direction.DOWN
            KeyEvent.KEYCODE_DPAD_LEFT -> PointerController.Direction.LEFT
            KeyEvent.KEYCODE_DPAD_RIGHT -> PointerController.Direction.RIGHT
            else -> return
        }
        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                pointerController.onDirectionDown(direction)
                startFrameLoop()
            }
            KeyEvent.ACTION_UP -> {
                pointerController.onDirectionUp(direction)
                if (!pointerController.hasActiveMovement()) stopFrameLoop()
            }
        }
    }

    private val frameLoop = object : Runnable {
        override fun run() {
            if (pointerController.tick()) {
                overlayParams.x = pointerController.x.toInt()
                overlayParams.y = pointerController.y.toInt()
                windowManager.updateViewLayout(overlayView, overlayParams)
            }
            if (pointerController.hasActiveMovement()) {
                mainHandler.postDelayed(this, FRAME_INTERVAL_MS)
            } else {
                frameLoopRunning = false
            }
        }
    }

    private fun startFrameLoop() {
        if (frameLoopRunning) return
        frameLoopRunning = true
        mainHandler.post(frameLoop)
    }

    private fun stopFrameLoop() {
        mainHandler.removeCallbacks(frameLoop)
        frameLoopRunning = false
    }

    private fun performTapAtCursor() {
        val path = Path().apply {
            moveTo(pointerController.x, pointerController.y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not used -- this service only needs key event filtering + gesture
        // dispatch, not window content inspection.
    }

    override fun onInterrupt() {
        stopFrameLoop()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopFrameLoop()
        if (::overlayView.isInitialized && ::windowManager.isInitialized) {
            runCatching { windowManager.removeView(overlayView) }
        }
    }
}
