package com.airboard.tvreceiver

import kotlin.math.max
import kotlin.math.min

/**
 * Tracks cursor position and converts sustained D-pad direction holds into
 * accelerating movement, similar to how OS-level "pointer via D-pad"
 * accessibility tools behave. Call [tick] on every animation frame (e.g. via
 * Choreographer or a Handler loop) while at least one direction is held.
 */
class PointerController(
    private val screenWidth: Int,
    private val screenHeight: Int
) {
    enum class Direction { UP, DOWN, LEFT, RIGHT }

    var x: Float = screenWidth / 2f
        private set
    var y: Float = screenHeight / 2f
        private set

    private val heldDirections = mutableSetOf<Direction>()
    private var holdStartTimeMs: Long = 0L

    companion object {
        private const val MIN_SPEED_PX_PER_TICK = 6f
        private const val MAX_SPEED_PX_PER_TICK = 42f
        // Time to go from min to max speed while a direction is held continuously.
        private const val RAMP_DURATION_MS = 900L
    }

    fun onDirectionDown(direction: Direction) {
        if (heldDirections.isEmpty()) {
            holdStartTimeMs = System.currentTimeMillis()
        }
        heldDirections.add(direction)
    }

    fun onDirectionUp(direction: Direction) {
        heldDirections.remove(direction)
        if (heldDirections.isEmpty()) {
            holdStartTimeMs = 0L
        }
    }

    fun hasActiveMovement(): Boolean = heldDirections.isNotEmpty()

    /** Advances the cursor position by one animation step. Returns true if position changed. */
    fun tick(): Boolean {
        if (heldDirections.isEmpty()) return false

        val elapsed = System.currentTimeMillis() - holdStartTimeMs
        val rampFraction = min(1f, elapsed / RAMP_DURATION_MS.toFloat())
        val speed = MIN_SPEED_PX_PER_TICK + rampFraction * (MAX_SPEED_PX_PER_TICK - MIN_SPEED_PX_PER_TICK)

        var dx = 0f
        var dy = 0f
        if (Direction.LEFT in heldDirections) dx -= speed
        if (Direction.RIGHT in heldDirections) dx += speed
        if (Direction.UP in heldDirections) dy -= speed
        if (Direction.DOWN in heldDirections) dy += speed

        // Diagonal holds (e.g. UP+LEFT both currently held) shouldn't move faster than
        // a single-direction hold.
        if (dx != 0f && dy != 0f) {
            dx *= 0.707f
            dy *= 0.707f
        }

        val newX = max(0f, min(screenWidth.toFloat(), x + dx))
        val newY = max(0f, min(screenHeight.toFloat(), y + dy))
        val changed = newX != x || newY != y
        x = newX
        y = newY
        return changed
    }

    fun reset() {
        x = screenWidth / 2f
        y = screenHeight / 2f
        heldDirections.clear()
        holdStartTimeMs = 0L
    }
}
