package com.airboard.keyboard

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.util.Log
import java.util.concurrent.Executor
import java.util.concurrent.Executors

/**
 * Wraps the Android BluetoothHidDevice profile to register this phone as a
 * Bluetooth HID keyboard peripheral, and exposes simple send-text / send-key
 * functions. The TV (or any BT host) sees this device as a normal keyboard
 * to pair with -- no custom protocol on the TV side is required for this half.
 *
 * Requires API 28+. Hardware support for the HID peripheral role varies by
 * device/chipset -- call `isProfileSupported()` before relying on this.
 */
class HidKeyboardManager(private val context: Context) {

    companion object {
        private const val TAG = "HidKeyboardManager"
    }

    interface ConnectionListener {
        fun onHidDeviceRegistered()
        fun onHidDeviceUnregistered()
        fun onConnectionStateChanged(device: BluetoothDevice?, state: Int)
        fun onAppUnavailable(reason: String)
    }

    private val bluetoothManager =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter? = bluetoothManager.adapter
    private val executor: Executor = Executors.newSingleThreadExecutor()

    private var hidDevice: BluetoothHidDevice? = null
    private var connectedDevice: BluetoothDevice? = null
    var listener: ConnectionListener? = null

    private val sdpSettings = BluetoothHidDeviceAppSdpSettings(
        "AirBoard Keyboard",
        "Phone-as-keyboard input for AirBoard",
        "AirBoard",
        BluetoothHidDevice.SUBCLASS1_COMBO,
        HidKeyboardConstants.KEYBOARD_REPORT_DESCRIPTOR
    )

    private val serviceListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            if (profile != BluetoothProfile.HID_DEVICE) return
            hidDevice = proxy as BluetoothHidDevice
            registerApp()
        }

        override fun onServiceDisconnected(profile: Int) {
            hidDevice = null
        }
    }

    private val hidCallback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            if (registered) {
                listener?.onHidDeviceRegistered()
            } else {
                listener?.onHidDeviceUnregistered()
            }
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            connectedDevice = if (state == BluetoothProfile.STATE_CONNECTED) device else null
            listener?.onConnectionStateChanged(device, state)
        }
    }

    fun isProfileSupported(): Boolean = adapter != null

    @SuppressLint("MissingPermission")
    fun start() {
        val a = adapter ?: run {
            listener?.onAppUnavailable("Bluetooth not available on this device")
            return
        }
        if (!a.isEnabled) {
            listener?.onAppUnavailable("Bluetooth is disabled")
            return
        }
        a.getProfileProxy(context, serviceListener, BluetoothProfile.HID_DEVICE)
    }

    @SuppressLint("MissingPermission")
    private fun registerApp() {
        val hid = hidDevice ?: return
        try {
            hid.registerApp(sdpSettings, null, null, executor, hidCallback)
        } catch (e: SecurityException) {
            listener?.onAppUnavailable("Missing Bluetooth permission: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        val hid = hidDevice ?: return
        try {
            connectedDevice?.let { hid.disconnect(it) }
            hid.unregisterApp()
        } catch (e: SecurityException) {
            Log.w(TAG, "Permission error while stopping HID app", e)
        }
        adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid)
        hidDevice = null
    }

    fun isConnected(): Boolean = connectedDevice != null

    /** Sends one full text string as a sequence of individual key-down/key-up reports. */
    fun sendText(text: String) {
        for (ch in text) {
            sendChar(ch)
        }
    }

    fun sendChar(ch: Char) {
        val (usage, modifier) = resolveUsage(ch) ?: return
        sendKeyReport(usage, modifier)
    }

    fun sendSpecialKey(usage: Int, modifier: Int = HidKeyboardConstants.MOD_NONE) {
        sendKeyReport(usage, modifier)
    }

    fun sendBackspace() = sendSpecialKey(HidKeyboardConstants.USAGE_BACKSPACE)
    fun sendEnter() = sendChar('\n')

    private fun resolveUsage(ch: Char): Pair<Int, Int>? {
        HidKeyboardConstants.CHAR_TO_USAGE[ch]?.let {
            return it to HidKeyboardConstants.MOD_NONE
        }
        HidKeyboardConstants.SHIFTED_CHAR_TO_USAGE[ch]?.let {
            return it to HidKeyboardConstants.MOD_LEFT_SHIFT
        }
        Log.w(TAG, "No HID mapping for character: $ch (0x${ch.code.toString(16)})")
        return null
    }

    @SuppressLint("MissingPermission")
    private fun sendKeyReport(usage: Int, modifier: Int) {
        val hid = hidDevice ?: return
        val device = connectedDevice ?: return

        val downReport = ByteArray(HidKeyboardConstants.REPORT_SIZE)
        downReport[0] = modifier.toByte()
        downReport[2] = usage.toByte() // first key slot

        val upReport = ByteArray(HidKeyboardConstants.REPORT_SIZE) // all zero = keys released

        try {
            hid.sendReport(device, HidKeyboardConstants.REPORT_ID.toInt(), downReport)
            hid.sendReport(device, HidKeyboardConstants.REPORT_ID.toInt(), upReport)
        } catch (e: SecurityException) {
            Log.w(TAG, "Permission error while sending report", e)
        }
    }
}
